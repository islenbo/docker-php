#define CAKEY  "FwWpZKxH7twCAG4JQMO"
//如果只允许执行加过密的php文件 设置STRICT_MODE为1
//set STRICT_MODE to 1 if you only want the crypted php files to be executed
#define STRICT_MODE 0
#define STRICT_MODE_ERROR_MESSAGE "ACCESS DENIED"
const int maxBytes = 1024*1024*2;